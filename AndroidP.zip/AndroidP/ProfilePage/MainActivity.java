package com.example.profilepage;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnBack = findViewById(R.id.btnBack);

        btnBack.setOnClickListener(v -> {

            // Open Login App
            Intent intent = getPackageManager()
                    .getLaunchIntentForPackage("com.example.loginpage");

            if (intent != null) {
                startActivity(intent);
                finish(); // Close profile app
            } else {
                Toast.makeText(MainActivity.this,
                        "Login App Not Installed",
                        Toast.LENGTH_LONG).show();
            }
        });
    }
}