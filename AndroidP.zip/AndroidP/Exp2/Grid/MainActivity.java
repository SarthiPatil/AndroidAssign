package com.example.grid;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);
        btn5 = findViewById(R.id.btn5);
        btn6 = findViewById(R.id.btn6);
        btn7 = findViewById(R.id.btn7);
        btn8 = findViewById(R.id.btn8);
        btn9 = findViewById(R.id.btn9);


        btn1.setOnClickListener(v -> openApp("com.example.relativelayout"));
        btn2.setOnClickListener(v -> openApp("com.example.linearlayout"));
        btn3.setOnClickListener(v -> openApp("com.example.tablelayout"));
        btn4.setOnClickListener(v -> openApp("com.example.gridlayout"));
        btn5.setOnClickListener(v -> openApp("com.example.framelayout"));
        btn6.setOnClickListener(v -> openApp("com.example.constraintlayout"));
        btn7.setOnClickListener(v -> openApp("com.example.button"));
        btn8.setOnClickListener(v -> openApp("com.example.implicit"));
        btn9.setOnClickListener(v -> openApp("com.example.profilepage"));
    }


    private void openApp(String packageName) {

        PackageManager packageManager = getPackageManager();
        Intent intent = packageManager.getLaunchIntentForPackage(packageName);

        if (intent != null) {
            startActivity(intent);
        } else {
            Toast.makeText(this, "App not installed", Toast.LENGTH_SHORT).show();
        }
    }
}