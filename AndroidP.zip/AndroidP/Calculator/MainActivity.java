package com.example.calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private TextView textViewDisplay;
    private String currentInput = "";
    private String operator = "";
    private double firstOperand = Double.NaN;
    private DecimalFormat decimalFormat = new DecimalFormat("#.##########");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        textViewDisplay = findViewById(R.id.textViewDisplay);

        View.OnClickListener numberClickListener = v -> {
            Button b = (Button) v;
            currentInput += b.getText().toString();
            textViewDisplay.setText(currentInput);
        };

        int[] numberIds = {
                R.id.button0, R.id.button1, R.id.button2, R.id.button3, R.id.button4,
                R.id.button5, R.id.button6, R.id.button7, R.id.button8, R.id.button9,
                R.id.buttonDot
        };

        for (int id : numberIds) {
            findViewById(id).setOnClickListener(numberClickListener);
        }

        View.OnClickListener operatorClickListener = v -> {
            Button b = (Button) v;
            if (!currentInput.isEmpty()) {
                if (!Double.isNaN(firstOperand)) {
                    calculate();
                } else {
                    firstOperand = Double.parseDouble(currentInput);
                }
                operator = b.getText().toString();
                currentInput = "";
            } else if (!Double.isNaN(firstOperand)) {
                // Allow changing the operator if a number was already calculated/entered
                operator = b.getText().toString();
            }
        };

        findViewById(R.id.buttonAdd).setOnClickListener(operatorClickListener);
        findViewById(R.id.buttonSubtract).setOnClickListener(operatorClickListener);
        findViewById(R.id.buttonMultiply).setOnClickListener(operatorClickListener);
        findViewById(R.id.buttonDivide).setOnClickListener(operatorClickListener);

        findViewById(R.id.buttonEqual).setOnClickListener(v -> {
            if (!operator.isEmpty() && !currentInput.isEmpty()) {
                calculate();
                operator = "";
            }
        });

        findViewById(R.id.buttonClear).setOnClickListener(v -> {
            currentInput = "";
            firstOperand = Double.NaN;
            operator = "";
            textViewDisplay.setText("0");
        });
    }

    private void calculate() {
        if (!Double.isNaN(firstOperand) && !currentInput.isEmpty()) {
            double secondOperand = Double.parseDouble(currentInput);
            switch (operator) {
                case "+":
                    firstOperand += secondOperand;
                    break;
                case "-":
                    firstOperand -= secondOperand;
                    break;
                case "*":
                    firstOperand *= secondOperand;
                    break;
                case "/":
                    if (secondOperand != 0) {
                        firstOperand /= secondOperand;
                    } else {
                        textViewDisplay.setText("Error");
                        firstOperand = Double.NaN;
                        currentInput = "";
                        operator = "";
                        return;
                    }
                    break;
            }
            textViewDisplay.setText(decimalFormat.format(firstOperand));
            currentInput = "";
        }
    }
}
