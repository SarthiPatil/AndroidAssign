package com.example.framelayout;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Find the button by its ID
        button = findViewById(R.id.button);

        // Set click listener
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Use getApplicationContext() instead of MainActivity.this
                Toast.makeText(getApplicationContext(), "Frame Layout Clicked!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}